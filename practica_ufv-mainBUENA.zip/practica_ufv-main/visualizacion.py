import pandas as pd
import streamlit as st
import plotly.express as px
import matplotlib
from matplotlib.backends.backend_agg import RendererAgg
import requests
import seaborn as sns
from typing import Optional

def load_data(url: str) -> Optional[pd.DataFrame]:
    """
    Load data from a given URL and return it as a pandas DataFrame.
    
    Args:
        url (str): The URL to fetch the data from.
        
    Returns:
        Optional[pd.DataFrame]: The loaded data as a pandas DataFrame, or None if the request fails.
    """
    response = requests.get(url)
    if response.status_code != 200:
        return None
    data_json = response.json()
    game_list = data_json['games']
    df = pd.DataFrame.from_records(game_list)
    return df

def info_box(texto, color=None):
    """
    Display an info box with the specified text.
    
    Args:
        texto (str): The text to display in the info box.
        color (str, optional): The background color of the info box. Defaults to None.
    """
    st.markdown(f'<div style="background-color:#4EBAE1; opacity:70%"><p style="text-align:center;color:white;font-size:30px;">{texto}</p></div>', unsafe_allow_html=True)

matplotlib.use("agg")
lock = RendererAgg.lock

df_merged = load_data('http://fastapi:8000/retrieve_data')