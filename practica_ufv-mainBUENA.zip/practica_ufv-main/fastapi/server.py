import shutil

import io
from fastapi.responses import JSONResponse
from fastapi import FastAPI, File, UploadFile,Form
import pandas as pd
from typing import  List

from pydantic import BaseModel as PydanticBaseModel

class BaseModel(PydanticBaseModel):
    class Config:
        arbitrary_types_allowed = True

class Games(BaseModel):

    rank:int
    name:str
    platform:str
    year:int
    genre:str
    publisher:str
    na_sales:float
    eu_sales:float
    jp_sales:float
    other_sales:float
    global_sales:float



class ListadoJuegos(BaseModel):
    games= List[Games]

app = FastAPI(
    title="Servidor de datos",
    description="""Servimos datos de contratos, pero podríamos hacer muchas otras cosas, la la la.""",
    version="0.1.0",
)


@app.get("/retrieve_data/")
#def insercion_endpoint (titulo:str = Form(...), autor:str=Form(...), pais:str=Form(...),genero:str=File(...),  archivo: UploadFile=File(...)):
def retrieve_data ():

    todosmisdatos = pd.read_csv('./vgsales.csv',sep=',')
    todosmisdatos = todosmisdatos.fillna(0)
    todosmisdatosdict = todosmisdatos.to_dict(orient='records')
    listado = ListadoJuegos()
    listado.games= todosmisdatosdict
    return listado

'''
@app.post("/retrieve_data/")
async def insercion_endpoint(
    nombre: str = Form(...),
    correo: str = Form(...),
    pais: str = Form(...),
    genero: str = Form(...),
    archivo: UploadFile = File(...)
):
    # Procesar el archivo, si se ha enviado
    contenido_archivo = None
    if archivo:
        contenido_archivo = await archivo.read()
    

    # Aqui se podrian procesar los datos recibidos y decidir que hacer con ellos( como guardarlos en una base de datos o realizar acciones específicas)

    return {
        "message": "Datos del formulario recibidos correctamente",
        "titulo": nombre,
        "autor": correo,
        "pais": pais,
        "genero": genero,
        "contenido_archivo": contenido_archivo  # Esto contendrá el contenido del archivo si se ha enviado
    }
'''


