import pandas as pd

import streamlit as st
import plotly.express as px

import matplotlib
import matplotlib.pyplot as plt
from matplotlib.backends.backend_agg import RendererAgg

import requests
import seaborn as sns



@st.cache_data
def load_data(url: str):
    r = requests.get(url)
    if r.status_code != 200:
        st.error("Error al cargar los datos")
        return pd.DataFrame()  # Devuelve un DataFrame vacío en caso de error
    mijson = r.json()

    if 'games' in mijson:
        listado = mijson['games']
        df = pd.DataFrame.from_records(listado)

        # Convertir las columnas de ventas a float, reemplazando valores no numéricos con NaN
        for column in ['NA_Sales', 'EU_Sales', 'JP_Sales', 'Other_Sales', 'Global_Sales']:
            df[column] = pd.to_numeric(df[column], errors='coerce')

        # Opcional: Eliminar filas con NaN si es necesario
        df.dropna(subset=['NA_Sales', 'EU_Sales', 'JP_Sales', 'Other_Sales', 'Global_Sales'], inplace=True)
        
        return df
    else:
        st.error("La respuesta JSON no contiene la clave 'games'")
        return pd.DataFrame()  # Devuelve un DataFrame vacío si no se encuentra 'games'



def info_box (texto, color=None):
    st.markdown(f'<div style = "background-color:#4EBAE1;opacity:70%"><p style="text-align:center;color:white;font-size:30px;">{texto}</p></div>', unsafe_allow_html=True)



matplotlib.use("agg")
lock = RendererAgg.lock

df_merged = load_data('http://fastapi:8000/retrieve_data')


rank = str(df_merged.shape[0]) 
name = str(len(df_merged.Name)) 
platform = str(len(df_merged.Platform.unique())) 
year = str(len(df_merged.Year.unique())) 
genre = str(len(df_merged.Genre.unique())) 
publisher = str(len(df_merged.Publisher.unique()))


na_sales = str(round(df_merged.NA_Sales.mean(), 2))
eu_sales = str(round(df_merged.EU_Sales.mean(), 2))
jp_sales = str(round(df_merged.JP_Sales.mean(), 2))
other_sales = str(round(df_merged.Other_Sales.mean(), 2))
global_sales = str(round(df_merged.Global_Sales.mean(), 2))


# Configuración de colores para la visualización
sns.set_palette("pastel")

# Encabezado principal
st.header("Información general sobre ventas de videojuegos")

# Creación de columnas para mostrar las métricas
col1, col2, col3 = st.columns(3)

col4, col5, col6 = st.columns(3)

with col1:
    col1.subheader('# Juegos')
    info_box(rank)

with col2:
    col2.subheader('# Plataformas')
    info_box(platform)

with col3:
    col3.subheader('# Géneros')
    info_box(genre)

with col4:
    col4.subheader('# Publicadores')
    info_box(publisher)

## Clases de medios digitales de publicacion
with col5:
    col5.subheader('# ventas globales medias')
    info_box(global_sales, col5)
with col6:
    col6.subheader('# ventas en Europa media')
    info_box(eu_sales, col6)

st.header("Seleccione el gráfico que desea ver")

# Opciones para seleccionar el gráfico
opciones_graficos = [
    'Ventas Globales por Año',
    'Distribución de Ventas por Región',
    'Ventas por Género de Juego',
    'Top 10 Videojuegos más Vendidos',
    'Ventas por Plataforma',
    'Evolución de las Ventas de las Principales Franquicias',
    'Correlación entre Ventas en Diferentes Regiones'
]

# Selección del usuario
opcion_seleccionada = st.selectbox('Seleccione el gráfico:', opciones_graficos)

# Crear gráficos interactivos
if opcion_seleccionada == 'Ventas Globales por Año':
    fig = px.line(df_merged.groupby('Year')['Global_Sales'].sum().reset_index(), x='Year', y='Global_Sales', title='Ventas Globales por Año')
elif opcion_seleccionada == 'Distribución de Ventas por Región':
    ventas_por_region = df_merged[['NA_Sales', 'EU_Sales', 'JP_Sales', 'Other_Sales']].sum()
    fig = px.bar(x=ventas_por_region.index, y=ventas_por_region.values, labels={'x': 'Región', 'y': 'Ventas Totales'}, title='Distribución de Ventas por Región')
elif opcion_seleccionada == 'Ventas por Género de Juego':
    ventas_por_genero = df_merged.groupby('Genre')['Global_Sales'].sum()
    fig = px.bar(x=ventas_por_genero.values, y=ventas_por_genero.index, orientation='h', labels={'x': 'Ventas Globales', 'y': 'Género'}, title='Ventas por Género de Juego')
elif opcion_seleccionada == 'Top 10 Videojuegos más Vendidos':
    top_videojuegos = df_merged.nlargest(10, 'Global_Sales')
    fig = px.bar(x='Global_Sales', y='Name', data_frame=top_videojuegos, labels={'x': 'Ventas Globales', 'y': 'Nombre del Videojuego'}, title='Top 10 Videojuegos más Vendidos')
elif opcion_seleccionada == 'Ventas por Plataforma':
    ventas_por_plataforma = df_merged.groupby('Platform')['Global_Sales'].sum().sort_values(ascending=False)
    fig = px.bar(x=ventas_por_plataforma.values, y=ventas_por_plataforma.index, orientation='h', labels={'x': 'Ventas Globales', 'y': 'Plataforma'}, title='Ventas por Plataforma')
elif opcion_seleccionada == 'Evolución de las Ventas de las Principales Franquicias':
    principales_franquicias = df_merged.groupby('Name')['Global_Sales'].sum().nlargest(5).index
    df_franquicias = df_merged[df_merged['Name'].isin(principales_franquicias)]
    ventas_franquicias_anuales = df_franquicias.groupby(['Name', 'Year'])['Global_Sales'].sum().reset_index()
    fig = px.line(data_frame=ventas_franquicias_anuales, x='Year', y='Global_Sales', color='Name', title='Evolución de las Ventas de las Principales Franquicias')
elif opcion_seleccionada == 'Correlación entre Ventas en Diferentes Regiones':
    fig = px.scatter(df_merged, x='NA_Sales', y='EU_Sales', title='Correlación entre Ventas en Norteamérica y Europa', labels={'x': 'Ventas en Norteamérica', 'y': 'Ventas en Europa'})

# Mostrar el gráfico seleccionado por el usuario
st.plotly_chart(fig)


'''
st.title('Formulario de Datos')

# Campos del formulario
nombre = st.text_input('Nombre')
correo = st.text_input('Correo')
pais = st.text_input('País')
genero = st.text_input('Género')

# Archivo adjunto
archivo = st.file_uploader('Subir archivo')


if st.button('Enviar'):
    # Se utiliza el import request

    url = 'http://fastapi:8000/retrieve_data'  # Reemplaza esto con la URL de tu servidor y el puerto correspondiente
    files = {'archivo': archivo.getvalue() if archivo else None}
    data = {'nombre': nombre, 'correo': correo, 'pais': pais, 'genero': genero}
    
    response = requests.post(url, files=files, data=data)
    
    # Manejo de la respuesta del servidor
    if response.status_code == 200:
        st.success('Datos enviados correctamente al servidor.')
    else:
        st.error('Hubo un error al enviar los datos al servidor.')
'''